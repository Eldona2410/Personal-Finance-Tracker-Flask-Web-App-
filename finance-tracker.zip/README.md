# Personal Finance Tracker

A simple **Personal Finance Tracker** built with **Flask (Python)** for the backend and **HTML/CSS/JS** for the frontend.  
It allows users to track their income, expenses, and balance with a clean interface.

---

## 🚀 Features
- Add income and expense transactions
- View all transactions
- See income, expense, and balance summary
- SQLite database with Flask SQLAlchemy
- Responsive frontend with vanilla HTML/JS

---

## 🛠️ Installation & Usage

### 1. Backend Setup (Flask)
```bash
cd server
pip install -r requirements.txt
python app.py
```
This runs the Flask API on `http://127.0.0.1:5000`.

### 2. Frontend Setup
Just open `client/index.html` in your browser.  
It will connect automatically to the Flask API.

---

## 📂 Project Structure
```
finance-tracker/
│── server/         # Flask backend
│   ├── app.py
│   ├── requirements.txt
│
│── client/         # Frontend
│   └── index.html
│
│── README.md
```

---

## 📄 License
This project is licensed under the MIT License.
